data = []

def inputData(): #요구사항 1.입력양식
    cnt = 'y'
    while cnt=='y':
        ipt = input("입력형식: ")
        name = input("장비명: ")
        count = input("수량: ")
        date = input("생산일(예:1990-01-01): ")
        cnt = input("계속입력하시겠습니까(y/n)?")
        data.append({'name':name, 'count':count, 'date': date})

def outputData(): #요구사항 2. 출력양식
    print('------------------------------------------')
    print('장비명      수량       생산일')
    print('------------------------------------------')
    for n in data:
        print("%(name)s        %(count)s        %(date)s"%n)

def searchData(): #요구사항 3. 검색양식
    sName = input("검색할 장비명을 입력하세요:")
    print('------------------------------------------')
    print('장비명      수량       생산일')
    print('------------------------------------------')
    for n in data:
        if sName == n.get('name'):
            print("%(name)s        %(count)s        %(date)s"%n)
            break

def endData(): #요구사항 4. 종료형식
    yeno = input("프로그램을 종료하시겠습니까(y/n)?")
    return(yeno)

d = {1:inputData, 2:outputData, 3:searchData, 4:endData}

#요구사항 0.메뉴
while True:
    print("1. 입력")
    print("2. 츨력")
    print("3. 검색")
    print("4. 종료")
    menu = int(input("메뉴를 선택하시오:"))

    res = d[menu]()
    if res == 'y':
        break
    elif res == 'n':
        continue

#inputData()
#outputData()
#searchData()

#d[menu]() # Switch 문처럼 구현
